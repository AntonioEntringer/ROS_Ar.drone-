arquivo = open("rastreamento.txt","w")          
arquivo.writelines("a")
arquivo.close()
x = 0
