#!/usr/bin/env python2.7
from __future__ import print_function

import rospy
import math
import cv2
import cv2.aruco as aruco
import numpy as np
import sys, select, termios, tty
from geometry_msgs.msg import Twist, Vector3
from nav_msgs.msg import Odometry
from std_msgs.msg import String, Empty, Float32
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
import time

erro_ant = 0
erro_sum = 0
z0 = 0


class Image_markers:
    img = None
    ids = None
    marer_size = None

    def __init__(self):

        self.image_pub = rospy.Publisher("image_new", Image, queue_size=10)
        self.bridge = CvBridge()
        self.arucoDict = cv2.aruco.Dictionary_get(aruco.DICT_ARUCO_ORIGINAL) #simulacao
        #self.arucoDict = cv2.aruco.Dictionary_get(aruco.DICT_4X4_50)  # drone

        self.arucoParams = cv2.aruco.DetectorParameters_create()
        rospy.Subscriber('/ardrone/bottom/image_raw', Image, self.callback_image)
        #rospy.Subscriber('/ardrone/image_raw', Image, self.callback_image)

        self.calib_path = ""
        #self.camera_matrix = np.loadtxt(self.calib_path + '/home/tonim/catkin_ws/src/opencv/src/scripts/cameraMatrix.txt', delimiter=',')
        #self.camera_distortion = np.loadtxt(self.calib_path + '/home/tonim/catkin_ws/src/opencv/src/scripts/cameraDistortion.txt', delimiter=',')

        self.camera_matrix = np.loadtxt(self.calib_path + '/home/tonim/catkin_ws/src/opencv/src/scripts/cameraMatrixGaz.txt', delimiter=',')
        self.camera_distortion = np.loadtxt(self.calib_path + '/home/tonim/catkin_ws/src/opencv/src/scripts/cameraDistortionGaz.txt', delimiter=',')

        rospy.sleep(1)

    def callback_image(self, data):

        try:
            self.img = self.bridge.imgmsg_to_cv2(data, "bgr8")
        except CvBridgeError as e:
            print(e)

        def isRotationMatrix(R):
            Rt = np.transpose(R)
            shouldBeIdentity = np.dot(Rt, R)
            I = np.identity(3, dtype=R.dtype)
            n = np.linalg.norm(I - shouldBeIdentity)
            return n < 1e-6

        def rotationMatrixToEulerAngles(R):
            assert (isRotationMatrix(R))

            sy = math.sqrt(R[0, 0] * R[0, 0] + R[1, 0] * R[1, 0])

            singular = sy < 1e-6

            if not singular:
                x = math.atan2(R[2, 1], R[2, 2])
                y = math.atan2(-R[2, 0], sy)
                z = math.atan2(R[1, 0], R[0, 0])
            else:
                x = math.atan2(-R[1, 2], R[1, 1])
                y = math.atan2(-R[2, 0], sy)
                z = 0

            return np.array([x, y, z])

        gray = cv2.cvtColor(self.img, cv2.COLOR_BGR2GRAY)
        corners, self.ids, rejected = cv2.aruco.detectMarkers(image=gray, dictionary=self.arucoDict,
                                                              parameters=self.arucoParams,
                                                              cameraMatrix=self.camera_matrix,
                                                              distCoeff=self.camera_distortion)
        img_marked = cv2.aruco.drawDetectedMarkers(self.img, corners)

        if self.ids != None:
            R_flip = np.zeros((3, 3), dtype=np.float32)
            R_flip[0, 0] = 1.0
            R_flip[1, 1] = -1.0
            R_flip[2, 2] = -1.0

            marer_size = 17
            ret = aruco.estimatePoseSingleMarkers(corners, marer_size, self.camera_matrix, self.camera_distortion)

            self.rvec, self.tvec = ret[0][0, 0, :], ret[1][0, 0, :]

            R_tc = np.matrix(cv2.Rodrigues(self.rvec)[0])

            R_ct = R_tc.T
            pos_camera = -R_ct * np.matrix(self.tvec).T

            roll_marker, pitch_marker, self.yaw_marker = rotationMatrixToEulerAngles(np.matmul(R_flip, R_ct))

            aruco.drawDetectedMarkers(img_marked, corners)
            aruco.drawAxis(img_marked, self.camera_matrix, self.camera_distortion, self.rvec, self.tvec, 10)

            font = cv2.FONT_HERSHEY_PLAIN
            # str_position = "MARKER Position x=%4.0f  y=%4.0f  z=%4.0f" % (
            str_position = "MARKER z=%4.0f" % (self.tvec[2])
            cv2.putText(img_marked, str_position, (0, 15), font, 1, (0, 255, 0), 2, cv2.LINE_AA)
            str_position = "MARKER y=%4.0f" % (self.tvec[1])
            cv2.putText(img_marked, str_position, (0, 35), font, 1, (0, 255, 0), 2, cv2.LINE_AA)
            str_position = "MARKER x=%4.0f" % (self.tvec[0])
            cv2.putText(img_marked, str_position, (0, 50), font, 1, (0, 255, 0), 2, cv2.LINE_AA)

            str_attitude = "MARKER Attitude r=%4.0f  p=%4.0f  y=%4.0f" % (
                math.degrees(roll_marker), math.degrees(pitch_marker), math.degrees(self.yaw_marker))
            cv2.putText(img_marked, str_attitude, (0, 80), font, 0.4, (0, 255, 0), 2, cv2.LINE_AA)

        try:
            self.image_pub.publish(self.bridge.cv2_to_imgmsg(img_marked, "bgr8"))
        except CvBridgeError as e:
            print(e)


def pid_x(erro, ts):
    global erro_ant
    global erro_sum

    p = 1
    i = 0.01
    d = 0.001

    kp = p
    ki = i * ts
    kd = d / ts

    erro_sum = erro_sum + erro
    vel_x = kp * erro + ki * erro_sum + kd * (erro - erro_ant)
    erro_ant = erro

    if vel_x > 0.3:
        vel_x = 0.3
    elif vel_x < -0.3:
        vel_x = -0.3

    return vel_x


def pid_y(erro, ts):
    global erro_ant
    global erro_sum

    p = 1
    i = 0.01
    d = 0.001

    kp = p
    ki = i * ts
    kd = d / ts

    erro_sum = erro_sum + erro
    vel_y = kp * erro + ki * erro_sum + kd * (erro - erro_ant)
    erro_ant = erro

    if vel_y > 0.3:
        vel_y = 0.3
    elif vel_y < -0.3:
        vel_y = -0.3

    return vel_y


def pid_z(z_ini, ts):
    global erro_ant
    global erro_sum

    erro = 1 - z_ini  # define a altura em metros

    p = 1
    i = 0.01
    d = 0.001

    kp = p
    ki = i * ts
    kd = d / ts

    erro_sum = erro_sum + erro
    vel_z = kp * erro + ki * erro_sum + kd * (erro - erro_ant)
    erro_ant = erro
    return vel_z


def pid_w(erro, ts):
    global erro_ant
    global erro_sum

    p = 1
    i = 0.01
    d = 0.001

    kp = p
    ki = i * ts
    kd = d / ts

    erro_sum = erro_sum + erro
    vel_w = kp * erro + ki * erro_sum + kd * (erro - erro_ant)
    erro_ant = erro

    #if vel_w > 0.2:
    #    vel_w = 0.2
    #elif vel_w < -0.2:
    #    vel_w = 0.2

    return vel_w


def callback(data):
    global z0

    z0 = data.pose.pose.position.z


def main(args):
    rospy.init_node('Controll', anonymous=True)
    pub_velocity = rospy.Publisher('cmd_vel', Twist , queue_size =10)
    pub_takeoff = rospy.Publisher("ardrone/takeoff", Empty, queue_size= 10)
    pub_land = rospy.Publisher("ardrone/land", Empty, queue_size=10)
    rospy.Subscriber('/ardrone/odometry', Odometry, callback)
    rospy.sleep(0.3)
    vel = Twist()
    mark = Image_markers()
    ts = 0.02
    pub_takeoff.publish(Empty())
    rospy.sleep(2)
    markoff = 0

    while True:
        vel.linear.x = (-pid_x(mark.tvec[1] / 100, ts))
        vel.linear.y = (-pid_y(mark.tvec[0] / 100, ts))
        vel.angular.z = pid_w(mark.yaw_marker, ts)
        if markoff < 400:
            vel.linear.z = (pid_z(mark.tvec[2] / 100, ts))

        #print("velocidade x: {},  velocidade y: {}, velocidade z: {}".format(vel.linear.x, vel.linear.y, vel.linear.z))
        #print(z0 , mark.tvec[2] / 100 )
        pub_velocity.publish(vel)
        rospy.sleep(ts)

        markoff = markoff + 1
        time.sleep(0.1)
        print(markoff*10, "Ms")

        if markoff > 400:
            vel.linear.x = (-pid_x(mark.tvec[1] / 100, ts))
            vel.linear.y = (-pid_y(mark.tvec[0] / 100, ts))
            vel.angular.z = pid_w(mark.yaw_marker, ts)

            print("!!!PUSANDO!!!")
            pub_land.publish(Empty())
            #time.sleep(2)




if __name__ == '__main__':
    rospy.init_node('Controll', anonymous=True)
    main(sys.argv)





