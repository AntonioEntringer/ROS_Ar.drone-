#!/usr/bin/env python2.7
import rospy 
import rospkg 
from gazebo_msgs.msg import ModelState 
from gazebo_msgs.srv import *
from std_msgs.msg import Float32
import math
from math import atan2
import numpy as np


def main():

    time = 0
    vel = 1
    x_ant = 3
    y_ant = 1.5
    theta = 0
    rospy.wait_for_service('/gazebo/set_model_state')

    set_state_service = rospy.ServiceProxy('/gazebo/set_model_state', SetModelState)
    pub_x = rospy.Publisher("/pose_aruco_x", Float32, queue_size = 10)
    pub_y = rospy.Publisher("/pose_aruco_y", Float32, queue_size = 10)
    pub_z = rospy.Publisher("/pose_aruco_z", Float32, queue_size=10)

    objstate = SetModelStateRequest()  # Create an object of type SetModelStateRequest
    objstate.model_state.pose.position.x = 3
    objstate.model_state.pose.position.y = 1.5
    resp = set_state_service( objstate )
    
    # set red cube pose
    while not rospy.is_shutdown():
        global array
        array = np.loadtxt('leminiscata.txt')
        objstate.model_state.model_name = "aruco_visual_marker_7"
        objstate.model_state.pose.position.x = 2*array[time,0]
        objstate.model_state.pose.position.y = 2*array[time,1]
        objstate.model_state.pose.position.z = 0.249

        objstate.model_state.reference_frame = "world"
        rospy.sleep(0.2)
        time = time + vel
    

        try:
            resp = set_state_service( objstate )
            pub_x.publish(objstate.model_state.pose.position.x)
            pub_y.publish(objstate.model_state.pose.position.y)
            pub_z.publish(objstate.model_state.pose.position.z)
        except rospy.ServiceException, e:
            print "Service call failed: %s" % e

if __name__ == '__main__':
    try:
        rospy.init_node('set_movel_aruco')
        main()
    except rospy.ROSInterruptException:
        pass
