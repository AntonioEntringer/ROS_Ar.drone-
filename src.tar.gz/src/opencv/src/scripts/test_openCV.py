#!/usr/bin/env python2.7
from __future__ import print_function

import rospy
import roslib
roslib.load_manifest('opencv')
import sys
from std_msgs.msg import String
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
import cv2
import cv2.aruco as aruco
import numpy as np


class Teste:

    def __init__(self):
        rospy.init_node('VIDEO', anonymous = True)
        self.pub = rospy.Publisher('New_video', Image, queue_size = 10)
        self.bridge = CvBridge()
        rospy.Subscriber('ardrone/image_raw', Image, self.callback)


    def callback(self, data):
        try:
            cv_image = self.bridge.imgmsg_to_cv2(data,"bgr8")
        except CvBridgeError as e:
            print(e)
        
        gray = cv2.cvtColor(cv_image, cv2.COLOR_BGR2GRAY)
        aruco_dict = aruco.Dictionary_get(aruco.DICT_4X4_250)
        arucoParameters = aruco.DetectorParameters_create()
        corners, ids, rejectedImgPoints = aruco.detectMarkers( gray, aruco_dict, parameters=arucoParameters)
        cv_image = aruco.drawDetectedMarkers(cv_image, corners)

        try:
            self.pub.publish(self.bridge.cv2_to_imgmsg(cv_image, "bgr8"))
        except CvBridgeError as e:
            print(e)


def main(args):
    t = Teste()
    try:
        rospy.spin()
    except KeyboardInterrupt:
        print("shutting down")
    cv2.destroyAllWindows()


if __name__ == '__main__':
    main(sys.argv)
