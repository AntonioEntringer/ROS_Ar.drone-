#!/usr/bin/env python2.7
import rospy
import math
import cv2
import cv2.aruco as aruco
import numpy as np
import sys
from geometry_msgs.msg import Twist,Vector3
from nav_msgs.msg import Odometry
from std_msgs.msg import String, Empty, Float32
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError


class Controll:

    x0 = y0 = z0 = w0 = None

    def pid_x(self,pf):
        kp = 0.5
        erro = (pf-self.x0)
        vel_x = kp*erro 
        if vel_x > 0.5:
            vel_x = 0.5
        elif vel_x < -0.5:
            vel_x = -0.5
        return vel_x

    def pid_y(self,pf):
        kp = 0.5
        erro = (pf-self.y0)
        vel_y = kp*erro
        if vel_y > 0.5:
            vel_y = 0.5
        elif vel_y < -0.5:
            vel_y = -0.5
        return vel_y

    def pid_z(self,p0):
        kp = 1
        pf = 0.8
        erro = (pf-p0)
        vel_z = kp*erro 
        return vel_z

    def pid_w(self,p0):
        kp = 2
        pf = 0.01
        erro = (pf-p0)
        vel_w = kp*erro
        return vel_w
        
    def __init__(self):

        self.pub_velocity = rospy.Publisher('cmd_vel', Twist , queue_size =10) #
        self.pub_takeoff = rospy.Publisher("ardrone/takeoff",Empty,queue_size= 10)
        self.vel = Twist()
        rospy.Subscriber('/my_odom', Odometry, self.callback_controll)
        rospy.sleep(1)
        
          
    def callback_controll(self, data):

        self.x0 = data.pose.pose.position.x
        self.y0 = data.pose.pose.position.y
        self.z0 = data.pose.pose.position.z
        self.w0 = data.pose.pose.orientation.z

        if self.z0 < 0.8:
            self.pub_takeoff.publish(Empty())
        
        self.vel.linear.z = self.pid_z(self.z0)
        self.vel.angular.z = self.pid_w(self.w0)


class Image_markers:

    img = None
    ids = None
    marer_size = None


    def pidw_x(self,d):
        kp = 0.8
        erro = d
        vel_x = kp*erro 
        if vel_x > 0.5:
            vel_x = 0.5
        elif vel_x < -0.5:
            vel_x = -0.5
        return vel_x
    
    def pidw_y(self,d):
        kp = 0.8
        erro = d
        vel_y = kp*erro
        if vel_y > 0.5:
            vel_y = 0.5
        elif vel_y < -0.5:
            vel_y = -0.5
        return vel_y



    def __init__(self):

        self.image_pub = rospy.Publisher("image_new", Image, queue_size=10)
        self.bridge = CvBridge()
        self.arucoDict = cv2.aruco.Dictionary_get(aruco.DICT_ARUCO_ORIGINAL)
        self.arucoParams = cv2.aruco.DetectorParameters_create()
        rospy.Subscriber('/ardrone/bottom/image_raw', Image, self.callback_image)

        self.calib_path = ""
        self.camera_matrix = np.loadtxt(self.calib_path + '/home/tonim/catkin_ws/src/opencv/src/scripts/cameraMatrixGaz.txt', delimiter=',')
        self.camera_distortion = np.loadtxt(self.calib_path + '/home/tonim/catkin_ws/src/opencv/src/scripts/cameraDistortionGaz.txt', delimiter=',')
        
        rospy.sleep(1)

    
    def callback_image(self,data):

        try:
            self.img = self.bridge.imgmsg_to_cv2(data,"bgr8")
        except CvBridgeError as e:
            print(e)


        def isRotationMatrix(R):
            Rt = np.transpose(R)
            shouldBeIdentity = np.dot(Rt, R)
            I = np.identity(3, dtype=R.dtype)
            n = np.linalg.norm(I - shouldBeIdentity)
            return n < 1e-6

        def rotationMatrixToEulerAngles(R):
            assert (isRotationMatrix(R))

            sy = math.sqrt(R[0, 0] * R[0, 0] + R[1, 0] * R[1, 0])

            singular = sy < 1e-6

            if not singular:
                x = math.atan2(R[2, 1], R[2, 2])
                y = math.atan2(-R[2, 0], sy)
                z = math.atan2(R[1, 0], R[0, 0])
            else:
                x = math.atan2(-R[1, 2], R[1, 1])
                y = math.atan2(-R[2, 0], sy)
                z = 0

            return np.array([x, y, z])

        #Print cornes and image capture
        gray = cv2.cvtColor(self.img, cv2.COLOR_BGR2GRAY)
        corners, self.ids, rejected = cv2.aruco.detectMarkers(image=gray, dictionary=self.arucoDict, parameters=self.arucoParams, cameraMatrix=self.camera_matrix, distCoeff=self.camera_distortion)
        img_marked = cv2.aruco.drawDetectedMarkers(self.img, corners)

        if self.ids != None:

            R_flip = np.zeros((3, 3), dtype=np.float32)
            R_flip[0, 0] = 1.0
            R_flip[1, 1] = -1.0
            R_flip[2, 2] = -1.0

            marer_size = 18
            ret = aruco.estimatePoseSingleMarkers(corners, marer_size, self.camera_matrix, self.camera_distortion)

            self.rvec, self.tvec = ret[0][0, 0, :], ret[1][0, 0, :]

            R_tc = np.matrix(cv2.Rodrigues(self.rvec)[0])

            R_ct = R_tc.T
            pos_camera = -R_ct * np.matrix(self.tvec).T

            roll_marker, pitch_marker, yaw_marker = rotationMatrixToEulerAngles(np.matmul(R_flip, R_ct))

            aruco.drawDetectedMarkers(img_marked, corners)
            aruco.drawAxis(img_marked, self.camera_matrix, self.camera_distortion, self.rvec, self.tvec, 10)


            font = cv2.FONT_HERSHEY_PLAIN
            str_position = "MARKER Position x=%4.0f  y=%4.0f  z=%4.0f" % (
            self.tvec[0],self.tvec[1],self.tvec[2])
            cv2.putText(img_marked, str_position, (0, 50), font, 1, (0, 255, 0), 2, cv2.LINE_AA)

            str_attitude = "MARKER Attitude r=%4.0f  p=%4.0f  y=%4.0f" % (
                math.degrees(roll_marker), math.degrees(pitch_marker), math.degrees(yaw_marker))
            cv2.putText(img_marked, str_attitude, (10, 80), font, 1, (0, 255, 0), 2, cv2.LINE_AA)

        try:
            self.image_pub.publish(self.bridge.cv2_to_imgmsg(img_marked, "bgr8"))          
        except CvBridgeError as e:
            print(e)


def main(args):
    x_pode = None
    y_pose = None
    rospy.init_node('Controll', anonymous=True)
    #rastreamento_x = rospy.Publisher("/rastreamento_x", Float32, queue_size = 10)
    #rastreamento_y = rospy.Publisher("/rastreamento_y", Float32, queue_size = 10)
    #rastreamento_z = rospy.Publisher("/rastreamento_z", Float32, queue_size = 10)
    controll = Controll()
    mark = Image_markers()
    matriz_pos = [[3, 0],[3, 0.5],[0, 0.5],[0, 1],[3, 1],[3, 1.5],
                 [0, 1.5],[0, 2],[3, 2],[3, 2.5],[0, 2.5],[0, 3],
                 [3, 3]]

    try:
        for i in range(len(matriz_pos)):
            while ((abs(matriz_pos[i][0]-controll.x0) >= 0.15) or (abs(matriz_pos[i][1])-controll.y0 >= 0.1)) and mark.ids == None:
                controll.vel.linear.x = controll.pid_x(matriz_pos[i][0])
                controll.vel.linear.y = controll.pid_y(matriz_pos[i][1])
                controll.pub_velocity.publish(controll.vel)
                rastreamento_x.publish(controll.x0)
                rastreamento_y.publish(controll.y0)
                rastreamento_z.publish(controll.z0)
                rospy.sleep(0.05)
            if mark.ids != None:
                x_pose = controll.x0
                y_pose = controll.y0
                break
        
        while True:
            controll.vel.linear.x = mark.pidw_x(-1*mark.tvec[1]/100)
            controll.vel.linear.y = mark.pidw_y(-1*mark.tvec[0]/100)
            controll.pub_velocity.publish(controll.vel)
            rastreamento_x.publish(controll.x0)
            rastreamento_y.publish(controll.y0)
            rospy.sleep(0.01)

    except KeyboardInterrupt:
        print("Shutting down")
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main(sys.argv)

    


