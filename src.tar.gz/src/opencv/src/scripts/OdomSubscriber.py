#!/usr/bin/env python
import time
import rospy
from nav_msgs.msg import Odometry
from std_msgs.msg import Empty
import tf
import rospkg
from gazebo_msgs.msg import ModelState
from gazebo_msgs.srv import *
from std_msgs.msg import Float32
import math
from math import atan2
from tf.transformations import euler_from_quaternion
from math import degrees
import numpy as np


def to_positive_angle(th):
    while True:
        if th < 0:
            th += 360
        if th > 0:
            ans = th % 360
            return ans
            break

def sub_odom():
    sub = rospy.Subscriber('/my_odom',Odometry, callback_odom)


def callback_odom(data):
    global x,y,th

    x = data.pose.pose.position.x + 0.10
    y = data.pose.pose.position.y
    q1 = data.pose.pose.orientation.x
    q2 = data.pose.pose.orientation.y
    q3 = data.pose.pose.orientation.z
    q4 = data.pose.pose.orientation.w
    q = (q1, q2, q3, q4)
    e = euler_from_quaternion(q)
    th = degrees(e[2])
    th = to_positive_angle(th)

    rospy.wait_for_service('/gazebo/set_model_state')
    set_state_service = rospy.ServiceProxy('/gazebo/set_model_state', SetModelState)
    pub_x = rospy.Publisher("/pose_aruco_x", Float32, queue_size=10)
    pub_y = rospy.Publisher("/pose_aruco_y", Float32, queue_size=10)
    pub_z = rospy.Publisher("/pose_aruco_z", Float32, queue_size=10)
    pub_q1 = rospy.Publisher("/orientation_aruco_q1", Float32, queue_size=10)
    pub_q2 = rospy.Publisher("/orientation_aruco_q2", Float32, queue_size=10)
    pub_q3 = rospy.Publisher("/orientation_aruco_q3", Float32, queue_size=10)
    pub_q4 = rospy.Publisher("/orientation_aruco_q4", Float32, queue_size=10)

    objstate = SetModelStateRequest()  # Create an object of type SetModelStateRequest
    objstate.model_state.pose.position.x = 0
    objstate.model_state.pose.position.y = 0
    resp = set_state_service(objstate)

    # set red cube pose


    objstate.model_state.reference_frame = "world"

    objstate.model_state.model_name = "aruco_visual_marker_7"
    objstate.model_state.pose.position.x = x
    objstate.model_state.pose.position.y = y
    objstate.model_state.pose.position.z = 0.249
    objstate.model_state.pose.orientation.w = q4
    objstate.model_state.pose.orientation.x = q1
    objstate.model_state.pose.orientation.y = q2
    objstate.model_state.pose.orientation.z = q3

    try:
        resp = set_state_service(objstate)
        pub_x.publish(objstate.model_state.pose.position.x)
        pub_y.publish(objstate.model_state.pose.position.y)
        pub_z.publish(objstate.model_state.pose.position.z)
        pub_q1.publish(objstate.model_state.pose.orientation.x)
        pub_q2.publish(objstate.model_state.pose.orientation.y)
        pub_q3.publish(objstate.model_state.pose.orientation.z)
        pub_q4.publish(objstate.model_state.pose.orientation.w)
    except q1 < 1000:
        print("erro")

x, y, th = 0.0, 0.0, 0.0

rospy.init_node("sub_odom")
rate = rospy.Rate(500)
## Reset odometry
pub = rospy.Publisher('/mobile_base/commands/reset_odometry' ,Empty, queue_size=10)
pub.publish()
time.sleep(5)


if __name__ == '__main__':
    sub_odom()

    #rospy.init_node('set_movel_aruco')
    #main()


    while not rospy.is_shutdown():
        #print "x:%.2f y:%.2f heading:%.2f"%(x, y, th)
        rate.sleep()
