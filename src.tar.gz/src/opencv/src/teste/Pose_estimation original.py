#!/usr/bin/env python2.7
import math
import cv2
import cv2.aruco as aruco
import numpy as np
from std_msgs.msg import Float64MultiArray
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
import rospy
import sys

class image_markers:
    first_time_seen = True
    R_tc1 = 0
    T_tc1 = 0
    yaw_marker1 = 0
    Deslocamento = None
    a = None
    array = None
    float = None

    def __init__(self):
        self.image_pub = rospy.Publisher("image_new", Image, queue_size=10)
        self.Deslocamento_pub = rospy.Publisher("Deslocamento_pub", Float64MultiArray, queue_size=1)
        self.bridge = CvBridge()
        self.float = Float64MultiArray()

        rospy.Subscriber('/ardrone/bottom/image_raw', Image, self.callback)
        self.arucoDict = cv2.aruco.Dictionary_get(aruco.DICT_4X4_250)
        self.arucoParams = cv2.aruco.DetectorParameters_create()
        # import calib path
        self.calib_path = ""
        self.camera_matrix = np.loadtxt(self.calib_path + '/home/mateus/simulador/src/opencv/src/teste/cameraMatrix.txt', delimiter=',')
        self.camera_distortion = np.loadtxt(self.calib_path + '/home/mateus/simulador/src/opencv/src/teste/cameraDistortion.txt', delimiter=',')
        self.img = None
        rospy.sleep(2)

    def callback(self, data):
        try:
            self.img = self.bridge.imgmsg_to_cv2(data, "bgr8")
        except CvBridgeError as e:
            print(e)

        def isRotationMatrix(R):
            Rt = np.transpose(R)
            shouldBeIdentity = np.dot(Rt, R)
            I = np.identity(3, dtype=R.dtype)
            n = np.linalg.norm(I - shouldBeIdentity)
            return n < 1e-6

        def rotationMatrixToEulerAngles(R):
            assert (isRotationMatrix(R))

            sy = math.sqrt(R[0, 0] * R[0, 0] + R[1, 0] * R[1, 0])

            singular = sy < 1e-6

            if not singular:
                x = math.atan2(R[2, 1], R[2, 2])
                y = math.atan2(-R[2, 0], sy)
                z = math.atan2(R[1, 0], R[0, 0])
            else:
                x = math.atan2(-R[1, 2], R[1, 1])
                y = math.atan2(-R[2, 0], sy)
                z = 0

            return np.array([x, y, z])

        #Print cornes and image capture
        gray = cv2.cvtColor(self.img, cv2.COLOR_BGR2GRAY)
        corners, ids, rejected = cv2.aruco.detectMarkers(image=gray, dictionary=self.arucoDict, parameters=self.arucoParams, cameraMatrix=self.camera_matrix, distCoeff=self.camera_distortion)
        img_marked = cv2.aruco.drawDetectedMarkers(self.img, corners)

        if ids != None:

            R_flip = np.zeros((3, 3), dtype=np.float32)
            R_flip[0, 0] = 1.0
            R_flip[1, 1] = -1.0
            R_flip[2, 2] = -1.0

            marer_size = 5
            ret = aruco.estimatePoseSingleMarkers(corners, marer_size, self.camera_matrix, self.camera_distortion)

            rvec, tvec = ret[0][0, 0, :], ret[1][0, 0, :]

            R_tc = np.matrix(cv2.Rodrigues(rvec)[0])

            R_ct = R_tc.T
            pos_camera = -R_ct * np.matrix(tvec).T

            roll_marker, pitch_marker, yaw_marker = rotationMatrixToEulerAngles(np.matmul(R_flip, R_ct))

            if self.first_time_seen == True:
                self.R_tc1 = R_tc
                self.T_tc1 = np.matrix(tvec).T
                self.yaw_marker1 = yaw_marker
                print(self.R_tc1)
                print(self.T_tc1)
                print(math.degrees(self.yaw_marker1))
                self.first_time_seen = False

            aruco.drawDetectedMarkers(img_marked, corners)
            aruco.drawAxis(img_marked, self.camera_matrix, self.camera_distortion, rvec, tvec, 10)
            aruco.drawAxis(img_marked, self.camera_matrix, self.camera_distortion, self.R_tc1, self.T_tc1, 10)

            pos_marker_C = pos_camera
            pos_marker_T = np.matmul(self.R_tc1, pos_marker_C) + self.T_tc1
            yaw_marker = yaw_marker - self.yaw_marker1

            font = cv2.FONT_HERSHEY_PLAIN

            str_position = "MARKER Position x=%4.0f  y=%4.0f  z=%4.0f" % (
            pos_marker_T[0], pos_marker_T[1], pos_marker_T[2])
            cv2.putText(img_marked, str_position, (0, 50), font, 1, (0, 255, 0), 2, cv2.LINE_AA)

            str_attitude = "MARKER Attitude r=%4.0f  p=%4.0f  y=%4.0f" % (
                math.degrees(roll_marker), math.degrees(pitch_marker), math.degrees(yaw_marker))
            cv2.putText(img_marked, str_attitude, (10, 80), font, 1, (0, 255, 0), 2, cv2.LINE_AA)
            #print(pos_marker_T[0], pos_marker_T[1], pos_marker_T[2])
            print(math.degrees(roll_marker), math.degrees(pitch_marker), math.degrees(yaw_marker))
            self.float.data = [[pos_marker_T[0]],[pos_marker_T[1]],[pos_marker_T[2]]]
            xx = float(pos_marker_T[0])
            yy = float(pos_marker_T[1])
            zz = float(pos_marker_T[2])

            posicao = [xx,yy,zz]
            float.data = posicao

        try:
            self.image_pub.publish(self.bridge.cv2_to_imgmsg(img_marked, "bgr8"))
            self.Deslocamento_pub.publish(self.float)

        except CvBridgeError as e:
            print(e)



def main(args):
    rospy.init_node('aruco', anonymous=True)
    rospy.sleep(1)
    mark = image_markers()
    try:
        rospy.spin()
    except KeyboardInterrupt:
        print("Shutting down")
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main(sys.argv)
